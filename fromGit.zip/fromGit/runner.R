library(shiny)    
if (interactive()) {
  runGitHub("shiny_example", "rstudio")
}
